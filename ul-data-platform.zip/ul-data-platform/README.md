# Smart Logistics Data & ML Platform — тестовое задание (Middle Data Engineer)

Сквозной прототип: **PostgreSQL 17 (raw → core → mart) → ETL/DQ → витрина коридора ставок → ML-прогноз тарифа**.

## Быстрый старт
```bash
# положите выданные файлы в sql/: schema.sql и synthetic.sql
cp .env.example .env
docker-compose up --build
```
Контейнер `pipeline` сам: применит `schema.sql` и `synthetic.sql` (если `public.prices` пуста), создаст
слои `core`/`mart`, запустит ETL, соберёт витрину, обучит модель, запишет прогнозы и прогонит тесты.
БД остаётся доступной на `localhost:${POSTGRES_PORT_HOST}`.

## Архитектура
| Слой | Где | Содержимое |
|---|---|---|
| raw / источник | схема `public` | таблицы из `sql/schema.sql` |
| core | `core.*` | `dim_city` (дедуп по `gc_id`), `prices_clean`, `dq_quarantine_prices`, `price_body_group` |
| mart | `mart.*` | `mart_route_card`, `mart_market_corridor` (view), `ml_price_predictions`, `ml_model_metrics` |

```
sql/dwh/01_ddl.sql ─ DDL         etl/ ─ Python-оркестрация (ELT на SQL)
sql/dwh/10_dims.sql              ml/  ─ признаки, обучение, batch-скоринг
sql/dwh/20_load_core.sql         tests/ ─ pytest (чистые + SQL smoke/идемпотентность)
sql/dwh/30_mart_route_card.sql   docker/ ─ Dockerfile, entrypoint
```
**Почему такой стек.** PostgreSQL достаточно для 300 тыс. строк, `percentile_cont` покрывает все
квартили. ELT в SQL вместо построчных вставок в Python: вся трансформация — set-based, Python
только оркестрирует и логирует. CatBoost — нативные категории (город/регион высокой кардинальности)
без ручного target-encoding и риска утечки. Бонусы (Airflow/Superset/ClickHouse) не реализованы:
шаги `etl.run_all --steps ...` ложатся в DAG один к одному.

## Этап 1. ETL и Data Quality
Правила применяются в порядке приоритета, на сделку сохраняется **первая** сработавшая причина
(`core.dq_quarantine_prices.dq_reason`):

| Код | Условие |
|---|---|
| `PRICE_NON_POSITIVE` | `price IS NULL OR price <= 0` |
| `RUB_PRICE_OUT_OF_RANGE` | RUB и `price <= 1000` (`DQ_RUB_MIN_PRICE`) |
| `DISTANCE_INVALID` | `distance IS NULL OR <= 0` |
| `NEGATIVE_WEIGHT` / `NEGATIVE_VOLUME` | `total_weight < 0` / `total_volume < 0` |
| `CITY_NOT_FOUND` | gcid отправления/назначения отсутствует в `cities` |
| `UNKNOWN_CURRENCY` | валюта не 643/840/978 |
| `FX_RATE_MISSING` | иностранная валюта без курса ровно на `nearest_rate_date` (fallback нет) |

* Конвертация: `price_rub = price * rate`, курс по точному `(num_code, setting_date = nearest_rate_date)`.
* `weight_category` / `volume_category` заполняются только при пропуске, по правилам задания (вес округляется до 0.1 т).
* `loading_city_gcid = unloading_city_gcid` **не** отбраковывается.
* `outlier_mark = true` строки остаются в core (флаг сохранён), но исключаются из витрины и ML. Флаг не пересчитывается.
* **Ограничение источника:** сделки последнего дня снимка (`2026-10-26`) ещё не прошли ночную разметку
  выбросов и имеют `outlier_mark = false` по умолчанию, поэтому могут содержать необнаруженные выбросы.
* Сохранность: `источник = core + карантин` (проверяется тестом).

**Идемпотентность / backfill.** Окно по `loading_date`; шаг `core` в одной транзакции делает
`DELETE` окна (core, карантин, группы кузова) и `INSERT` из staging. Повторный запуск не даёт дублей.
```bash
docker-compose run --rm pipeline python -m etl.run_all --steps core,mart \
    --start-date 2026-09-01 --end-date 2026-09-30
```
Витрина всегда пересобирается целиком (нужна история для MoM/YoY) — тоже идемпотентно.

## Этап 2. Витрина `mart.mart_route_card`
Grain: `month_start × loading_city_gcid × unloading_city_gcid × body_group × weight_category`.
* Города дедуплицируются (`DISTINCT ON (gc_id) ORDER BY id`), JOIN идёт к `core.dim_city`.
* Кузов → `Тент` (56–61), `Рефрижератор` (4,46–48), `Изотерм` (2), `Борт` (1,15), `Прочие`, `Не указан`.
  Если у сделки несколько типов кузова, она попадает в каждую свою группу один раз (PK
  `price_id, body_group`) — корридор по группе не двоит цену. Для ML берётся одна группа с минимальным приоритетом.
* Фильтры: `is_fact`, `NOT complex`, `NOT outlier_mark`, `price_rub > 0`, `distance > 0`, `price_date <= as_of`.
  Месяц берётся из `price_dates`; если у сделки нет строк в `price_dates` — из `loading_date`.
* Метрики: P25/P50/P75/avg за рейс, P25/P50/P75 за км, `trips_count`, `carriers_count`
  (`price_type IN (3,9)`), `cv_rate`, `mom_pct`, `yoy_pct` (строго календарный сдвиг, иначе NULL),
  `reliability_level`. «Свежесть» = `as_of − max(дата данных ячейки) ≤ 30` дней.

Проверочные запросы: `sql/dwh/99_checks.sql`.

## Этап 3. ML
* Признаки: город/регион отправления и назначения (раздельно), координаты, расстояние, вес, объём,
  группа кузова, категории, тип записи, год/месяц/день недели/день года + sin/cos (T = 12, 7, 365.25).
* **Без утечек:** не используются `price`, `price_with_vat`, `price/distance`, `price/weight`, маржа/прибыль,
  `price_group_stats`, `price_group_id`, `outlier_mark` как признак (только как фильтр таргета).
  Всё обучаемое (импутер, скейлер, энкодер, CatBoost) учится только на train. Тест `test_no_leaky_features`.
* **Time split:** train `[2026-07-26, 2026-10-05)`, test `[2026-10-05, 2026-10-26]`, без shuffle.
* Модели: `CatBoostRegressor` (основная, `random_seed=42`, фиксированное число итераций, без early stopping по test)
  и `Ridge` как бейзлайн. Таргет обучается в `log1p(price_rub)`, метрики считаются в рублях.
* Скоринг: test-период + заявки с `loading_date > as_of` → `mart.ml_price_predictions`
  (для будущих `actual/abs_error/ape` = NULL). Перезапись по модели — идемпотентна.
* Метрики пишутся в лог и в `mart.ml_model_metrics`.

### Метрики (заполнить после запуска)
```sql
SELECT model_name, n_train, n_test, r2, mape_pct, rmse_rub, mae_rub FROM mart.ml_model_metrics;
```
| Модель | R² | MAPE % | RMSE руб. | MAE руб. |
|---|---|---|---|---|
| catboost_v1 | _см. запрос_ | | | |
| ridge_baseline | | | | |

## Допущения
Файлы `schema.sql`/`synthetic.sql` при написании не были доступны, имена колонок взяты из текста
задания: `prices(id, loading_date, created_at, loading_city_gcid, unloading_city_gcid, distance,
total_weight, total_volume, body_type, price, currency_code, price_type, "complex", nearest_rate_date,
outlier_mark, organization_id, weight_category, volume_category)`, `price_body_types(price_id, body_type_id)`,
`price_dates(price_id, price_date)`, `exchange_rates(num_code, value, setting_date)`.
Если названия отличаются — правится только `sql/dwh/*.sql`. `exchange_rates.value` трактуется как руб. за единицу валюты.
Условие «RUB price ≤ 1000» трактуется как отбраковка слишком малых ставок.
